import'dart:io';
import 'package:image/image.dart' as img;
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:plant_disease_detection/utils/image_utils.dart';
import 'package:plant_disease_detection/utils/constants.dart';

// Classe pour TensorBuffer
class TensorBuffer {
  List<double> data;
  TensorBuffer(this.data);

  double getDouble(int index) {
    return data[index];
  }

  Map<int, double>getDoubleMap() {
    Map<int, double> result = {};
    for (int i = 0; i < data.length; i++) {
      result[i] = data[i];
    }
    return result;
  }
}

// Constante locale pour float32
const int float32 = 32;

// Classe abstraite définissant la structure de base pour les chargeurs de modèle
abstract class ModelLoader {
  late Interpreter interpreter; // Interpréteur TensorFlow Lite

  // Méthode pour charger le modèle depuis les assets
  Future<void> loadModel(String modelPath) async {
    try {
      interpreter = await Interpreter.fromAsset(modelPath);
      print('Modèle chargé avec succès : $modelPath'); // Log de succès
    } catch (e) {
      print('Erreur lors du chargement du modèle : $modelPath - $e'); // Log d'erreur
    }
  }

  // Méthode pour effectuer la prédiction sur une image
  Future<Map<String, dynamic>> predict(File imageFile) async {
    // Prétraitement de l'image : redimensionnement et conversion en ByteBuffer
    img.Image inputImage =
    await ImageUtils.loadImageAndResize(imageFile, getInputSize());
    var input = ImageUtils.imageToByteBuffer(inputImage);

    // Création d'un TensorBuffer pour stocker lasortie du modèle
    var output = TensorBuffer([0.0]); // Initialise avec une valeur par défaut

    // Exécution de l'inférence du modèle
    interpreter.run(input, output.data); // Utilise output.data pour accéder aux données

    // Récupération de la sortie du modèle sous forme de Map
    Map<int, double> mapOutput = output.getDoubleMap();

    // Recherche de l'indice de la classe avec la probabilité la plus élevée
    int maxIndex = mapOutput.entries
        .reduce((a, b) => a.value > b.value ? a : b)
        .key;

    // Obtention de la probabilité maximale
    double confidence = mapOutput[maxIndex]!;

    // Utilisation de la liste de labels pour obtenir le nom de la classe prédite
    String prediction = Constants.labels[maxIndex];

    // Vérification du seuil de confiance et retour du résultat
    return {
      'prediction': confidence >= Constants.confidenceThreshold
          ? prediction
          : 'Prédiction incertaine',
      'confidence': confidence
    };
  }

  // Méthodes abstraites pour obtenir la taille d'entrée et de sortie
  int getInputSize();
  int getOutputSize();

  // Méthode pour fermer l'interpréteur
  void close() {
    interpreter.close();
  }
}