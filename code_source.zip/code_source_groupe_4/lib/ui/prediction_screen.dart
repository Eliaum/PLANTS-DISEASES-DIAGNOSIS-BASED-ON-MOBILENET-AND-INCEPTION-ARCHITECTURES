import 'package:flutter/material.dart';
import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'home_screen.dart';

class PredictionScreen extends StatefulWidget {
  final String imagePath;
  final Interpreter model;

  const PredictionScreen({Key? key, required this.imagePath, required this.model}) : super(key: key);

  @override
  _PredictionScreenState createState() => _PredictionScreenState();
}

class _PredictionScreenState extends State<PredictionScreen> {
  File? _image;
  String? _prediction;
  double? _confidence;
  String? _description;
  String? _recommendations;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _image = File(widget.imagePath);
    _predictImage();
  }

  Future<void> _predictImage() async {
    setState(() {
      _isLoading = true;
    });

    final modelLoader = MyModelLoader(); // Crée une instance de MyModelLoader
    final result = await modelLoader.predict(_image!); // Appelle predict sur l'instance
    setState(() {
      _prediction = result['label'];
      _confidence = double.tryParse(result['confidence'].toString());
      _description = getDiseaseDescription(_prediction!);
      _recommendations = getRecommendations(_prediction!);
      _isLoading = false;
    });
  }


  void _clearImage() {
    setState(() {
      _image = null;
      _prediction = null;
      _confidence = null;
      _description = null;
      _recommendations = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Prédiction')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            if (_image != null) ...[
              CachedNetworkImage(
                imageUrl: _image!.path,
                placeholder: (context, url) => CircularProgressIndicator(),
                errorWidget: (context, url, error) => Icon(Icons.error),
                width: 200,
                height: 200,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _clearImage,
                child: Text('Effacer l\'image'),
              ),
            ] else
              Text('Aucune image sélectionnée.'),
            SizedBox(height: 20),
            if (_isLoading)
              CircularProgressIndicator()
            else if (_prediction != null)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Prédiction: $_prediction', style: TextStyle(fontWeight: FontWeight.bold)),
                  if (_confidence != null)
                    Text('Confiance: ${(_confidence! * 100).toStringAsFixed(2)}%'),
                  if (_description != null)
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Text(
                        'Description: $_description',
                        textAlign: TextAlign.justify,
                      ),
                    ),
                  if (_recommendations != null)
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Text(
                        'Recommandations: $_recommendations',
                        textAlign: TextAlign.justify,
                      ),
                    ),
                ],
              )
            else
              Container(),
          ],
        ),
      ),
    );
  }

  String getDiseaseDescription(String disease) {
    switch (disease) {
      case 'Apple___Apple_scab':
        return 'La tavelure du pommier est une maladie fongique qui affecte les pommes et qui se manifeste par des taches brunes ou noires sur les feuilles, les fruits et les rameaux. Elle peut entraîner une défoliation prématurée, une réduction de la qualité des fruits et une diminution du rendement.';
      case 'Apple___Black_rot':
        return 'La pourriture noire du pommier est une maladie fongique qui affecte les pommes et qui se manifeste par des taches brunes sur les feuilles, les fruits et les rameaux. Les fruits infectés développent des lésions noires et se momifient. La maladie peut entraîner une défoliation, une chute prématurée des fruits et une diminution du rendement.';
    // ... Ajoutez d'autres cas pour les autres maladies
      default:
        return 'Description non disponible.';
    }
  }

  String getRecommendations(String disease) {
    switch (disease) {
      case 'Apple___Apple_scab':
        return 'Pour lutter contre la tavelure du pommier, il est recommandé d\'utiliser des fongicides adaptés et de pratiquer des techniques culturales appropriées, comme l\'élagage et la suppression des feuilles infectées.';
      case 'Apple___Black_rot':
        return 'Pour lutter contre la pourriture noire du pommier, il est recommandé d\'utiliser des fongicides adaptés et de pratiquer des techniques culturales appropriées, comme l\'élagage et la suppression des fruits infectés.';
    // ... Ajoutez d'autres cas pour les autres maladies
      default:
        return 'Recommandations non disponibles.';
    }
  }
}