import 'dart:io';
import'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:plant_disease_detection/model_loader.dart';
import 'package:plant_disease_detection/ui/prediction_screen.dart';
import 'package:tflite_flutter/tflite_flutter.dart';

// Classe concrète qui étend ModelLoader
class MyModelLoader extends ModelLoader {
  @override
  int getInputSize() {
    return 224; // Remplace par la taille d'entrée de ton modèle
  }

  @override
  int getOutputSize() {
    return 10; // Remplace par la taille de sortie de ton modèle
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  File? _selectedImage;
  Interpreter? _modelInception;
  Interpreter? _modelMobileNet;
  String? _selectedModel;

  Future<void> _getImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _selectedImage = File(pickedFile.path);
      });
    }
  }

  Future<void> _loadModelInception() async {
    final modelLoader = MyModelLoader();
    await modelLoader.loadModel('assets/model_inception_rmsprop.tflite'); // Charge le modèle
    setState(() {
      _modelInception = modelLoader.interpreter; // Utilise l'interpreter du modelLoader
    });
  }

  Future<void> _loadModelMobileNet() async {
    final modelLoader = MyModelLoader();
    await modelLoader.loadModel('assets/model_mobilenet_rmsprop.tflite'); // Charge le modèle
    setState(() {
      _modelMobileNet = modelLoader.interpreter; // Utilise l'interpreter du modelLoader
    });
  }

  @override
  void initState() {
    super.initState();
    _loadModelInception();
    _loadModelMobileNet();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Détection de Maladies des Plantes'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: _getImage,
              child: const Text('Sélectionner une image'),
            ),
            const SizedBox(height: 20),
            if (_selectedImage != null)
              Column(
                children: [
                  DropdownButton<String>(
                    value: _selectedModel,
                    hint: const Text('Sélectionner un modèle'),
                    items: ['MobileNetV2', 'InceptionV3'].map((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      );
                    }).toList(),
                    onChanged: (newValue) {
                      setState(() {
                        _selectedModel = newValue;
                      });
                    },
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: _selectedModel != null && _selectedImage != null
                        ? () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => PredictionScreen(
                            imagePath: _selectedImage!.path,
                            model: _selectedModel == 'MobileNetV2'
                                ? _modelMobileNet!
                                : _modelInception!,
                          ),
                        ),
                      );
                    }
                        : null,
                    child: const Text('Analyser'),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}