import 'dart:io';
import 'package:flutter/services.dart';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:image/image.dart' as img;
import 'package:plant_disease_detection/utils/constants.dart';
import 'package:plant_disease_detection/utils/image_utils.dart';
import '../model_loader.dart';

class InceptionModelLoader extends ModelLoader {
  Interpreter? _interpreter;

  @override
  Future<void> loadModel(String modelPath) async {
    final model = await rootBundle.load(Constants.inceptionModelPath);
    _interpreter = await Interpreter.fromBuffer(model.buffer.asUint8List());
  }

  @override
  Future<Map<String, dynamic>> predict(File imageFile) async {
    img.Image inputImage = await ImageUtils.loadImageAndResize(imageFile, getInputSize());
    var input = ImageUtils.imageToByteBuffer(inputImage);

    var output = List<double>.filled(Constants.inceptionOutputSize, 0.0);

    _interpreter!.run(input, output);

    int maxIndex = output.indexOf(output.reduce((a, b) => a > b ? a : b));
    double confidence = output[maxIndex];
    String prediction = Constants.labels[maxIndex];

    if (confidence < Constants.confidenceThreshold) {
      prediction = "Prédiction incertaine";
    }

    return {'prediction': prediction, 'confidence': confidence};
  }

  @override
  int getInputSize() {
    return Constants.inceptionInputSize;
  }

  @override
  int getOutputSize() {
    return Constants.inceptionOutputSize;
  }
}