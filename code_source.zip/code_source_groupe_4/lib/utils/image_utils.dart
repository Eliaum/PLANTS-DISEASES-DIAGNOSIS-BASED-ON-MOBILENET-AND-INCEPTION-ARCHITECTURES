import 'dart:io';
import 'package:image/image.dart' as img;
import 'dart:typed_data';

class ImageUtils {
  static Future<img.Image> loadImageAndResize(File imageFile, int targetSize) async {
    final bytes = await imageFile.readAsBytes();
    final inputImage = img.decodeImage(bytes);
    if (inputImage == null) {
      throw Exception('Impossible de décoder l\'image.');
    }
    return img.copyResize(inputImage, width: targetSize, height: targetSize);
  }

  static ByteBuffer imageToByteBuffer(img.Image image) {
    var buffer = Float32List(image.width * image.height * 3);
    var index = 0;

    for (var y = 0; y < image.height; y++) {
      for (var x = 0; x < image.width; x++) {
        var pixel = image.getPixel(x, y);

        // Extraire les composantes RVB du pixel
        buffer[index++] = pixel.r / 255.0; // Rouge
        buffer[index++] = pixel.g / 255.0; // Vert
        buffer[index++] = pixel.b / 255.0; // Bleu
      }
    }

    return buffer.buffer;
  }

}
