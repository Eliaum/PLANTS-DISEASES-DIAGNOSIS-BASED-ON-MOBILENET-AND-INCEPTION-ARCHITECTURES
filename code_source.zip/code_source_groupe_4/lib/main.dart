import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:plant_disease_detection/model_loader.dart' as model_loader;
import 'package:plant_disease_detection/models/model_mobilenet.dart' as mobilenet_model;
import 'package:plant_disease_detection/models/model_inception.dart' as inception_model;
import 'package:plant_disease_detection/utils/constants.dart';
import 'dart:io';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Détection de Maladie des Plantes',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(title: 'Détection de Maladie des Plantes'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  File? _image;
  String _prediction = '';
  double _confidence = 0.0;
  String _selectedModel = Constants.mobilenetModelName;
  bool _isLoading = false;

  Future<void> _getImage(ImageSource source) async {
    final imagePicker = ImagePicker();
    final XFile? pickedImage = await imagePicker.pickImage(source: source);
    if (pickedImage != null) {
      setState(() {
        _image = File(pickedImage.path);
      });
    }
  }

  Future<void> _predict() async {
    if (_image == null) {
      return;
    }

    setState(() {
      _isLoading = true;
    });

    model_loader.ModelLoader modelLoader;
    if (_selectedModel == Constants.mobilenetModelName) {
      modelLoader = mobilenet_model.MobileNetModelLoader();
    } else {
      modelLoader = inception_model.InceptionModelLoader();
    }

    final predictionResult = await modelLoader.predict(_image!);

    setState(() {
      _prediction = predictionResult['label'];
      _confidence = predictionResult['confidence'];
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            DropdownButton<String>(
              value: _selectedModel,
              hint: Text('Choisir un modèle'),
              items: [
                DropdownMenuItem(
                  value: Constants.mobilenetModelName,
                  child: Text(Constants.mobilenetModelName),
                ),
                DropdownMenuItem(
                  value: Constants.inceptionModelName,
                  child: Text(Constants.inceptionModelName),
                ),
              ],
              onChanged: (value) {
                setState(() {
                  _selectedModel = value!;
                });
              },
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => _getImage(ImageSource.gallery),
              child: Text('Charger une Image'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => _getImage(ImageSource.camera),
              child: Text('Capturer une Image'),
            ),
            SizedBox(height: 20),
            if (_image != null)
              Image.file(
                _image!,
                height: 200,
                width: 200,
                fit: BoxFit.cover,
              ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _predict,
              child: Text('Analyser'),
            ),
            SizedBox(height: 20),
            if (_isLoading)
              CircularProgressIndicator(),
            SizedBox(height: 20),
            Text('Prédiction: $_prediction'),
            SizedBox(height: 10),
            Text('Confiance: $_confidence'),
            SizedBox(height: 20),
            // Ajoutez ici les sections pour afficher les informations sur la maladie, les traitements, etc.
          ],
        ),
      ),
    );
  }
}
